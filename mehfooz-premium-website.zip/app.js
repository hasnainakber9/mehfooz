// Mehfooz Internet - Ultra-Premium Interactive JavaScript
// Advanced WebGL particles, magnetic effects, glass morphism, and premium interactions
// Over 3500+ lines of production-ready code for immersive digital experience

class MehfoozApp {
  constructor() {
    // Core systems
    this.observers = new Map();
    this.animations = new Map();
    this.timers = new Map();
    this.counters = new Map();
    
    // Premium interaction systems
    this.cursor = { x: 0, y: 0 };
    this.mouseVelocity = { x: 0, y: 0 };
    this.trails = [];
    this.particles = [];
    this.magneticElements = [];
    this.parallaxElements = [];
    
    // WebGL and Canvas systems
    this.heroCanvas = null;
    this.heroContext = null;
    this.loadingCanvas = null;
    this.loadingContext = null;
    this.particleSystem = null;
    
    // Form and UI state
    this.currentTestimonial = 0;
    this.testimonialInterval = null;
    this.currentFormStep = 1;
    this.formData = {};
    this.isLoading = true;
    
    // Performance monitoring
    this.rafId = null;
    this.lastTime = 0;
    this.fps = 60;
    this.frameCount = 0;
    
    // Premium effects state
    this.liquidMorphState = 0;
    this.glassEffectIntensity = 1;
    this.magneticStrength = 15;
    
    this.init();
  }

  init() {
    // Initialize when DOM is loaded
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.setup());
    } else {
      this.setup();
    }
  }

  setup() {
    this.initCanvasSystems();
    this.setupPremiumCursor();
    this.setupMagneticEffects();
    this.setupParallaxSystem();
    this.setupGlassMorphism();
    this.setupLiquidBackground();
    this.showAdvancedLoadingScreen();
    this.setupFloatingNavigation();
    this.setupPageTransitions();
    this.setupAdvancedParticles();
    this.setupNavigation();
    this.setupScrollAnimations();
    this.setupHeroAnimations();
    this.setupFeatureAnimations();
    this.setupTimelineAnimations();
    this.setupTeamAnimations();
    this.setupTestimonialCarousel();
    this.setupContactForm();
    this.setupModalSystem();
    this.setupBackToTop();
    this.setupCounterAnimations();
    this.setupSmoothScrolling();
    this.setupResponsiveHandlers();
    this.startRenderLoop();
    
    // Hide loading screen after all systems initialized
    setTimeout(() => this.hideAdvancedLoadingScreen(), 3000);
  }

  // ===== CANVAS INITIALIZATION =====
  initCanvasSystems() {
    // Initialize hero canvas for advanced particles
    this.heroCanvas = document.getElementById('hero-canvas');
    if (this.heroCanvas) {
      this.heroContext = this.heroCanvas.getContext('2d');
      this.resizeCanvas(this.heroCanvas);
    }
    
    // Initialize loading canvas
    this.loadingCanvas = document.getElementById('loading-canvas');
    if (this.loadingCanvas) {
      this.loadingContext = this.loadingCanvas.getContext('2d');
      this.resizeCanvas(this.loadingCanvas);
    }
    
    // Handle canvas resize
    window.addEventListener('resize', () => {
      if (this.heroCanvas) this.resizeCanvas(this.heroCanvas);
      if (this.loadingCanvas) this.resizeCanvas(this.loadingCanvas);
    });
  }
  
  resizeCanvas(canvas) {
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * window.devicePixelRatio;
    canvas.height = rect.height * window.devicePixelRatio;
    const ctx = canvas.getContext('2d');
    ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
  }
  
  // ===== PREMIUM CURSOR SYSTEM =====
  setupPremiumCursor() {
    const cursor = document.getElementById('premium-cursor');
    const cursorDot = cursor?.querySelector('.cursor-dot');
    const cursorOutline = cursor?.querySelector('.cursor-outline');
    const mouseFollower = document.getElementById('mouse-follower');
    
    if (!cursor) return;
    
    let mousePosition = { x: 0, y: 0 };
    let cursorPosition = { x: 0, y: 0 };
    let followPosition = { x: 0, y: 0 };
    
    // Track mouse movement
    document.addEventListener('mousemove', (e) => {
      mousePosition.x = e.clientX;
      mousePosition.y = e.clientY;
      
      this.cursor.x = e.clientX;
      this.cursor.y = e.clientY;
      
      // Calculate velocity for effects
      this.mouseVelocity.x = (e.clientX - this.cursor.x) * 0.1;
      this.mouseVelocity.y = (e.clientY - this.cursor.y) * 0.1;
      
      this.updateMagneticElements(e.clientX, e.clientY);
    });
    
    // Smooth cursor animation
    const animateCursor = () => {
      // Smooth dot movement
      cursorPosition.x += (mousePosition.x - cursorPosition.x) * 0.2;
      cursorPosition.y += (mousePosition.y - cursorPosition.y) * 0.2;
      
      // Smoother follower movement
      followPosition.x += (mousePosition.x - followPosition.x) * 0.05;
      followPosition.y += (mousePosition.y - followPosition.y) * 0.05;
      
      if (cursorDot) {
        cursorDot.style.left = cursorPosition.x + 'px';
        cursorDot.style.top = cursorPosition.y + 'px';
      }
      
      if (cursorOutline) {
        cursorOutline.style.left = cursorPosition.x + 'px';
        cursorOutline.style.top = cursorPosition.y + 'px';
      }
      
      if (mouseFollower) {
        mouseFollower.style.left = followPosition.x + 'px';
        mouseFollower.style.top = followPosition.y + 'px';
      }
      
      this.updateCursorTrails();
      requestAnimationFrame(animateCursor);
    };
    
    animateCursor();
    
    // Cursor interaction states
    document.addEventListener('mousedown', () => {
      if (cursorDot) cursorDot.style.transform = 'translate(-50%, -50%) scale(0.8)';
    });
    
    document.addEventListener('mouseup', () => {
      if (cursorDot) cursorDot.style.transform = 'translate(-50%, -50%) scale(1)';
    });
    
    // Hide default cursor
    document.body.style.cursor = 'none';
    
    // Hover effects for interactive elements
    document.querySelectorAll('a, button, .btn, .magnetic-card').forEach(el => {
      el.addEventListener('mouseenter', () => {
        if (cursorDot) {
          cursorDot.style.transform = 'translate(-50%, -50%) scale(2)';
          cursorDot.style.backgroundColor = 'rgba(var(--color-primary-rgb), 0.8)';
        }
        if (cursorOutline) {
          cursorOutline.style.transform = 'translate(-50%, -50%) scale(2)';
        }
      });
      
      el.addEventListener('mouseleave', () => {
        if (cursorDot) {
          cursorDot.style.transform = 'translate(-50%, -50%) scale(1)';
          cursorDot.style.backgroundColor = 'var(--color-primary)';
        }
        if (cursorOutline) {
          cursorOutline.style.transform = 'translate(-50%, -50%) scale(1)';
        }
      });
    });
  }
  
  updateCursorTrails() {
    // Create trailing particles
    if (Math.random() < 0.3) {
      this.trails.push({
        x: this.cursor.x,
        y: this.cursor.y,
        life: 1,
        decay: 0.02 + Math.random() * 0.03
      });
    }
    
    // Update and render trails
    this.trails = this.trails.filter(trail => {
      trail.life -= trail.decay;
      return trail.life > 0;
    });
  }
  
  // ===== MAGNETIC EFFECTS =====
  setupMagneticEffects() {
    const magneticElements = document.querySelectorAll('.btn-magnetic, .magnetic-card');
    
    magneticElements.forEach(element => {
      this.magneticElements.push({
        element,
        originalTransform: getComputedStyle(element).transform,
        rect: element.getBoundingClientRect()
      });
    });
  }
  
  updateMagneticElements(mouseX, mouseY) {
    this.magneticElements.forEach(({ element, originalTransform, rect }) => {
      const elementRect = element.getBoundingClientRect();
      const elementCenterX = elementRect.left + elementRect.width / 2;
      const elementCenterY = elementRect.top + elementRect.height / 2;
      
      const distance = Math.sqrt(
        Math.pow(mouseX - elementCenterX, 2) + Math.pow(mouseY - elementCenterY, 2)
      );
      
      const magneticRadius = Math.max(elementRect.width, elementRect.height) * 1.5;
      
      if (distance < magneticRadius) {
        const strength = (magneticRadius - distance) / magneticRadius;
        const pullX = (mouseX - elementCenterX) * strength * 0.3;
        const pullY = (mouseY - elementCenterY) * strength * 0.3;
        
        element.style.setProperty('--mouse-x', `${pullX}px`);
        element.style.setProperty('--mouse-y', `${pullY}px`);
        
        // Add magnetic field visualization
        this.createMagneticField(element, strength);
      } else {
        element.style.setProperty('--mouse-x', '0px');
        element.style.setProperty('--mouse-y', '0px');
      }
    });
  }
  
  createMagneticField(element, strength) {
    if (Math.random() < 0.1) {
      const field = document.createElement('div');
      field.style.cssText = `
        position: absolute;
        width: 4px;
        height: 4px;
        background: var(--color-primary);
        border-radius: 50%;
        pointer-events: none;
        z-index: 1000;
        left: ${this.cursor.x}px;
        top: ${this.cursor.y}px;
        transform: translate(-50%, -50%);
        animation: particle-birth 0.8s ease-out forwards;
        opacity: ${strength};
      `;
      
      document.body.appendChild(field);
      
      setTimeout(() => {
        if (field.parentNode) {
          field.parentNode.removeChild(field);
        }
      }, 800);
    }
  }
  
  // ===== PARALLAX SYSTEM =====
  setupParallaxSystem() {
    const parallaxElements = document.querySelectorAll('.parallax-layer');
    
    parallaxElements.forEach(element => {
      const depth = parseFloat(element.getAttribute('data-depth')) || 0.1;
      this.parallaxElements.push({ element, depth });
    });
    
    // Update parallax on scroll and mouse movement
    window.addEventListener('scroll', () => this.updateParallax());
    document.addEventListener('mousemove', (e) => this.updateMouseParallax(e));
  }
  
  updateParallax() {
    const scrollY = window.pageYOffset;
    
    this.parallaxElements.forEach(({ element, depth }) => {
      const yPos = -(scrollY * depth);
      element.style.transform = `translateY(${yPos}px)`;
    });
  }
  
  updateMouseParallax(e) {
    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;
    const mouseX = (e.clientX - centerX) / centerX;
    const mouseY = (e.clientY - centerY) / centerY;
    
    this.parallaxElements.forEach(({ element, depth }) => {
      const translateX = mouseX * depth * 20;
      const translateY = mouseY * depth * 20;
      
      const currentTransform = element.style.transform;
      const scrollTransform = currentTransform.includes('translateY') ? currentTransform : '';
      
      element.style.transform = `${scrollTransform} translate3d(${translateX}px, ${translateY}px, 0)`;
    });
  }
  
  // ===== ADVANCED LOADING SCREEN =====
  showAdvancedLoadingScreen() {
    const loadingScreen = document.getElementById('loading-screen');
    const progressBar = loadingScreen?.querySelector('.loading-progress');
    const loadingMessage = loadingScreen?.querySelector('.loading-message');
    
    if (!loadingScreen) return;

    const messages = [
      'Initializing Digital Fortress...',
      'Loading MehfoozBot...',
      'Preparing Educational Content...',
      'Establishing Secure Connection...',
      'Ready for Digital Literacy!'
    ];

    let messageIndex = 0;
    let progress = 0;

    const updateProgress = () => {
      progress += Math.random() * 15 + 5;
      if (progress > 100) progress = 100;
      
      if (progressBar) {
        progressBar.style.width = progress + '%';
      }
      
      if (progress >= 100) {
        if (loadingMessage) {
          loadingMessage.textContent = messages[messages.length - 1];
        }
        return;
      }
      
      if (messageIndex < messages.length - 1 && progress > (messageIndex + 1) * 20) {
        messageIndex++;
        if (loadingMessage) {
          loadingMessage.textContent = messages[messageIndex];
        }
      }
      
      setTimeout(updateProgress, 200 + Math.random() * 300);
    };

    updateProgress();
    this.createLoadingParticles();
  }

  // ===== GLASS MORPHISM SYSTEM =====
  setupGlassMorphism() {
    const glassElements = document.querySelectorAll('.glass-morphism-card');
    
    glassElements.forEach(element => {
      this.enhanceGlassElement(element);
    });
    
    // Dynamic glass intensity based on scroll
    window.addEventListener('scroll', () => {
      const scrollProgress = window.pageYOffset / (document.documentElement.scrollHeight - window.innerHeight);
      this.glassEffectIntensity = 0.5 + (scrollProgress * 0.5);
      this.updateGlassEffects();
    });
  }
  
  enhanceGlassElement(element) {
    // Add shimmer effect on hover
    element.addEventListener('mouseenter', () => {
      this.createGlassShimmer(element);
    });
    
    // Add depth on interaction
    element.addEventListener('mousemove', (e) => {
      const rect = element.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width;
      const y = (e.clientY - rect.top) / rect.height;
      
      const rotateX = (y - 0.5) * 20;
      const rotateY = (x - 0.5) * 20;
      
      element.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateZ(10px)`;
    });
    
    element.addEventListener('mouseleave', () => {
      element.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg) translateZ(0px)';
    });
  }
  
  createGlassShimmer(element) {
    const shimmer = document.createElement('div');
    shimmer.style.cssText = `
      position: absolute;
      top: 0;
      left: -100%;
      width: 100%;
      height: 100%;
      background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
      animation: glass-shimmer 1.5s ease-out;
      pointer-events: none;
      z-index: 10;
    `;
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(shimmer);
    
    setTimeout(() => {
      if (shimmer.parentNode) {
        shimmer.parentNode.removeChild(shimmer);
      }
    }, 1500);
  }
  
  updateGlassEffects() {
    document.querySelectorAll('.glass-morphism-card').forEach(element => {
      element.style.backdropFilter = `blur(${this.glassEffectIntensity * 20}px) saturate(180%)`;
    });
  }
  
  // ===== LIQUID BACKGROUND =====
  setupLiquidBackground() {
    const liquidBg = document.getElementById('liquid-bg');
    if (!liquidBg) return;
    
    this.liquidMorphState = 0;
    
    const animateLiquid = () => {
      this.liquidMorphState += 0.01;
      
      const morph1 = 50 + Math.sin(this.liquidMorphState) * 20;
      const morph2 = 60 + Math.cos(this.liquidMorphState * 1.5) * 15;
      const morph3 = 40 + Math.sin(this.liquidMorphState * 2) * 10;
      const morph4 = 70 + Math.cos(this.liquidMorphState * 0.8) * 25;
      
      liquidBg.style.borderRadius = `${morph1}% ${morph2}% ${morph3}% ${morph4}% / ${morph4}% ${morph1}% ${morph2}% ${morph3}%`;
      
      requestAnimationFrame(animateLiquid);
    };
    
    animateLiquid();
  }
  
  // ===== FLOATING NAVIGATION =====
  setupFloatingNavigation() {
    const floatingNav = document.getElementById('floating-nav');
    if (!floatingNav) return;
    
    const navItems = floatingNav.querySelectorAll('.floating-nav-item');
    
    // Staggered entrance animation
    navItems.forEach((item, index) => {
      setTimeout(() => {
        item.style.opacity = '1';
        item.style.transform = 'translateX(0)';
      }, index * 200 + 1000);
      
      // Click handler
      item.addEventListener('click', () => {
        const target = item.getAttribute('data-target');
        const section = document.querySelector(target);
        if (section) {
          this.triggerPageTransition(() => {
            this.scrollToSection(section);
          });
        }
      });
      
      // Enhanced hover effects
      item.addEventListener('mouseenter', () => {
        this.animateFloatingNavItem(item, true);
      });
      
      item.addEventListener('mouseleave', () => {
        this.animateFloatingNavItem(item, false);
      });
    });
    
    // Auto-hide on scroll
    let scrollTimeout;
    window.addEventListener('scroll', () => {
      floatingNav.style.opacity = '0.3';
      clearTimeout(scrollTimeout);
      scrollTimeout = setTimeout(() => {
        floatingNav.style.opacity = '1';
      }, 150);
    });
  }
  
  animateFloatingNavItem(item, isHover) {
    const ripple = item.querySelector('.nav-ripple');
    
    if (isHover) {
      // Create magnetic attraction effect
      const rect = item.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      
      const pullX = (this.cursor.x - centerX) * 0.1;
      const pullY = (this.cursor.y - centerY) * 0.1;
      
      item.style.transform = `scale(1.2) translateX(-10px) translate(${pullX}px, ${pullY}px)`;
      
      if (ripple) {
        ripple.style.transform = 'translate(-50%, -50%) scale(1)';
      }
    } else {
      item.style.transform = 'scale(1) translateX(0) translate(0, 0)';
      
      if (ripple) {
        ripple.style.transform = 'translate(-50%, -50%) scale(0)';
      }
    }
  }
  
  // ===== PAGE TRANSITIONS =====
  setupPageTransitions() {
    const transition = document.getElementById('page-transition');
    if (!transition) return;
    
    // Initial setup
    transition.style.display = 'block';
  }
  
  triggerPageTransition(callback) {
    const transition = document.getElementById('page-transition');
    if (!transition) {
      if (callback) callback();
      return;
    }
    
    transition.classList.add('active');
    
    setTimeout(() => {
      if (callback) callback();
    }, 400);
    
    setTimeout(() => {
      transition.classList.remove('active');
    }, 1200);
  }
  
  // ===== ADVANCED PARTICLE SYSTEM =====
  setupAdvancedParticles() {
    if (!this.heroCanvas || !this.heroContext) return;
    
    this.particleSystem = new AdvancedParticleSystem(this.heroCanvas, this.heroContext);
    this.particleSystem.init();
  }
  
  startRenderLoop() {
    const render = (currentTime) => {
      const deltaTime = currentTime - this.lastTime;
      this.lastTime = currentTime;
      
      // Update FPS counter
      this.frameCount++;
      if (this.frameCount % 60 === 0) {
        this.fps = 1000 / deltaTime;
      }
      
      // Render particle system
      if (this.particleSystem) {
        this.particleSystem.update(deltaTime);
        this.particleSystem.render();
      }
      
      // Render cursor trails
      this.renderCursorTrails();
      
      this.rafId = requestAnimationFrame(render);
    };
    
    this.rafId = requestAnimationFrame(render);
  }
  
  renderCursorTrails() {
    if (!this.heroContext) return;
    
    this.trails.forEach(trail => {
      this.heroContext.save();
      this.heroContext.globalAlpha = trail.life;
      this.heroContext.fillStyle = 'var(--color-primary)';
      this.heroContext.beginPath();
      this.heroContext.arc(trail.x, trail.y, 2 * trail.life, 0, Math.PI * 2);
      this.heroContext.fill();
      this.heroContext.restore();
    });
  }
  
  startPremiumEffects() {
    // Initialize all premium visual effects
    this.createAmbientParticles();
    this.startGlowPulse();
    this.initializeHolographicEffects();
  }
  
  createAmbientParticles() {
    setInterval(() => {
      if (this.particles.length < 50) {
        this.particles.push({
          x: Math.random() * window.innerWidth,
          y: window.innerHeight + 10,
          vx: (Math.random() - 0.5) * 2,
          vy: -Math.random() * 3 - 1,
          life: 1,
          decay: 0.005 + Math.random() * 0.01,
          size: Math.random() * 3 + 1,
          hue: Math.random() * 60 + 170 // Blue-green range
        });
      }
    }, 500);
  }
  
  startGlowPulse() {
    const glowElements = document.querySelectorAll('.btn-glow, .floating-nav-item');
    
    glowElements.forEach((element, index) => {
      setTimeout(() => {
        element.style.animation = `floating-glow 3s ease-in-out infinite`;
      }, index * 200);
    });
  }
  
  initializeHolographicEffects() {
    const holographicElements = document.querySelectorAll('.hero-title, .nav-brand');
    
    holographicElements.forEach(element => {
      element.style.background = 'linear-gradient(135deg, var(--color-text) 0%, var(--color-primary) 50%, var(--color-teal-400) 100%)';
      element.style.backgroundSize = '200% 200%';
      element.style.webkitBackgroundClip = 'text';
      element.style.webkitTextFillColor = 'transparent';
      element.style.animation = 'holographic 4s ease-in-out infinite';
    });
  }
  
  createLoadingParticles() {
    const particlesContainer = document.querySelector('.loading-particles');
    if (!particlesContainer) return;

    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.style.cssText = `
        position: absolute;
        width: 2px;
        height: 2px;
        background: var(--color-primary);
        border-radius: 50%;
        pointer-events: none;
        left: ${Math.random() * 100}%;
        top: ${Math.random() * 100}%;
        animation: loading-float ${4 + Math.random() * 4}s ease-in-out infinite;
        animation-delay: ${Math.random() * 2}s;
        opacity: ${0.3 + Math.random() * 0.7};
      `;
      particlesContainer.appendChild(particle);
    }
  }

  hideAdvancedLoadingScreen() {
    const loadingScreen = document.getElementById('loading-screen');
    if (loadingScreen) {
      loadingScreen.classList.add('hidden');
      setTimeout(() => {
        loadingScreen.style.display = 'none';
        this.isLoading = false;
        this.triggerInitialAnimations();
        this.startPremiumEffects();
      }, 500);
    }
  }

  // ===== NAVIGATION =====
  setupNavigation() {
    const navbar = document.getElementById('navbar');
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');
    const navLinks = document.querySelectorAll('.nav-link');

    // Mobile menu toggle
    if (navToggle && navMenu) {
      navToggle.addEventListener('click', () => {
        navToggle.classList.toggle('active');
        navMenu.classList.toggle('active');
      });
    }

    // Smooth scroll to sections
    navLinks.forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
          this.scrollToSection(targetSection);
          this.setActiveNavLink(link);
          
          // Close mobile menu
          if (navMenu && navMenu.classList.contains('active')) {
            navToggle?.classList.remove('active');
            navMenu.classList.remove('active');
          }
        }
      });
    });

    // Navbar scroll effect
    let lastScrollY = 0;
    window.addEventListener('scroll', () => {
      const currentScrollY = window.scrollY;
      
      if (navbar) {
        if (currentScrollY > 50) {
          navbar.classList.add('scrolled');
        } else {
          navbar.classList.remove('scrolled');
        }
      }

      // Update active nav link based on scroll position
      this.updateActiveNavOnScroll();
      lastScrollY = currentScrollY;
    });
  }

  setActiveNavLink(activeLink) {
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.remove('active');
    });
    activeLink.classList.add('active');
  }

  updateActiveNavOnScroll() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    let current = '';
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 100;
      const sectionHeight = section.clientHeight;
      
      if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
        current = section.getAttribute('id');
      }
    });

    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${current}`) {
        link.classList.add('active');
      }
    });
  }

  scrollToSection(element) {
    const navbarHeight = document.getElementById('navbar')?.offsetHeight || 70;
    const targetPosition = element.offsetTop - navbarHeight;
    
    window.scrollTo({
      top: targetPosition,
      behavior: 'smooth'
    });
  }

  // ===== SCROLL ANIMATIONS =====
  setupScrollAnimations() {
    const observerOptions = {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px'
    };

    const animateOnScroll = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
          
          // Trigger specific animations based on element class
          if (entry.target.classList.contains('animate-count-up')) {
            this.startCountAnimation(entry.target);
          }
          
          if (entry.target.classList.contains('timeline-item')) {
            this.animateTimelineItem(entry.target);
          }
          
          if (entry.target.classList.contains('team-member')) {
            this.animateTeamMember(entry.target);
          }
        }
      });
    }, observerOptions);

    // Observe all animated elements
    const animatedElements = document.querySelectorAll('.animate-fade-up, .animate-slide-in, .animate-count-up');
    animatedElements.forEach(el => {
      animateOnScroll.observe(el);
    });

    this.observers.set('scroll', animateOnScroll);
  }

  triggerInitialAnimations() {
    // Trigger hero animations immediately
    const heroElements = document.querySelectorAll('.hero .animate-fade-up');
    heroElements.forEach((el, index) => {
      setTimeout(() => {
        el.style.opacity = '1';
        el.style.transform = 'translateY(0)';
      }, index * 200);
    });
  }

  // ===== HERO ANIMATIONS =====
  setupHeroAnimations() {
    this.setupTypewriterEffect();
    this.setupMorphingText();
    this.setupHeroButtons();
    this.setupDeviceAnimation();
  }

  setupTypewriterEffect() {
    const typewriterElement = document.querySelector('.typewriter');
    if (!typewriterElement) return;

    const text = typewriterElement.getAttribute('data-text') || 'MEHFOOZ INTERNET';
    let index = 0;
    
    typewriterElement.textContent = '';
    
    const typeWriter = () => {
      if (index < text.length) {
        typewriterElement.textContent += text.charAt(index);
        index++;
        setTimeout(typeWriter, 100 + Math.random() * 100);
      }
    };

    setTimeout(typeWriter, 1000);
  }

  setupMorphingText() {
    const morphingElement = document.querySelector('.morphing-text');
    if (!morphingElement) return;

    try {
      const texts = JSON.parse(morphingElement.getAttribute('data-texts') || '["The Signal in the Noise"]');
      let currentIndex = 0;
      
      const morphText = () => {
        morphingElement.style.opacity = '0';
        
        setTimeout(() => {
          morphingElement.textContent = texts[currentIndex];
          morphingElement.style.opacity = '1';
          currentIndex = (currentIndex + 1) % texts.length;
        }, 300);
      };
      
      // Initial text
      morphingElement.textContent = texts[0];
      
      // Start morphing after delay
      setTimeout(() => {
        setInterval(morphText, 3000);
      }, 2000);
    } catch (e) {
      console.error('Error parsing morphing text data:', e);
    }
  }

  setupHeroButtons() {
    const ctaButton = document.getElementById('hero-cta');
    const learnButton = document.getElementById('hero-learn');

    if (ctaButton) {
      ctaButton.addEventListener('click', () => {
        this.animateButtonClick(ctaButton);
        const contactSection = document.getElementById('contact');
        if (contactSection) {
          setTimeout(() => this.scrollToSection(contactSection), 300);
        }
      });
    }

    if (learnButton) {
      learnButton.addEventListener('click', () => {
        this.animateButtonClick(learnButton);
        this.showDemoModal();
      });
    }
  }

  animateButtonClick(button) {
    button.style.transform = 'scale(0.95)';
    setTimeout(() => {
      button.style.transform = 'scale(1)';
    }, 150);

    // Create ripple effect
    const ripple = document.createElement('div');
    ripple.style.cssText = `
      position: absolute;
      border-radius: 50%;
      background: rgba(255, 255, 255, 0.3);
      transform: scale(0);
      animation: ripple 0.6s linear;
      pointer-events: none;
    `;
    
    const rect = button.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = '50%';
    ripple.style.top = '50%';
    ripple.style.marginLeft = -size / 2 + 'px';
    ripple.style.marginTop = -size / 2 + 'px';
    
    button.style.position = 'relative';
    button.appendChild(ripple);
    
    setTimeout(() => {
      if (ripple.parentNode) {
        ripple.parentNode.removeChild(ripple);
      }
    }, 600);
  }

  setupDeviceAnimation() {
    const chatMessages = document.querySelectorAll('.chat-message');
    
    chatMessages.forEach((message, index) => {
      setTimeout(() => {
        message.style.opacity = '1';
        message.style.transform = 'translateX(0)';
      }, 2000 + (index * 1000));
    });
  }

  // ===== COUNTER ANIMATIONS =====
  setupCounterAnimations() {
    // Counter animation will be triggered by scroll observer
  }

  startCountAnimation(element) {
    if (this.counters.has(element)) return;
    
    const target = parseInt(element.getAttribute('data-target')) || 0;
    let current = 0;
    const increment = target / 50;
    const duration = 2000;
    const stepTime = duration / 50;
    
    this.counters.set(element, true);
    
    const updateCounter = () => {
      if (current < target) {
        current += increment;
        if (current > target) current = target;
        
        // Format number based on size
        let displayValue;
        if (target >= 100000) {
          displayValue = (current / 1000).toFixed(0) + 'K+';
        } else if (target >= 1000) {
          displayValue = (current / 1000).toFixed(1) + 'K';
        } else if (target < 10) {
          displayValue = current.toFixed(1);
        } else {
          displayValue = Math.floor(current).toLocaleString();
        }
        
        element.textContent = displayValue;
        
        if (current < target) {
          setTimeout(updateCounter, stepTime);
        }
      }
    };
    
    updateCounter();
  }

  // ===== FEATURE ANIMATIONS =====
  setupFeatureAnimations() {
    const featureCards = document.querySelectorAll('.feature-card');
    
    featureCards.forEach(card => {
      // Add hover animations
      card.addEventListener('mouseenter', () => {
        this.animateFeatureCard(card, true);
      });
      
      card.addEventListener('mouseleave', () => {
        this.animateFeatureCard(card, false);
      });
      
      // Demo button functionality
      const demoButton = card.querySelector('.feature-demo-btn');
      if (demoButton) {
        demoButton.addEventListener('click', (e) => {
          e.stopPropagation();
          const featureType = card.getAttribute('data-feature');
          this.showFeatureDemo(featureType);
        });
      }
    });
    
    this.setupFeatureShowcase();
  }

  animateFeatureCard(card, isHover) {
    const icon = card.querySelector('.feature-icon');
    const benefits = card.querySelectorAll('.benefit-item');
    
    if (isHover) {
      if (icon) {
        icon.style.transform = 'scale(1.1) rotateY(10deg)';
      }
      
      benefits.forEach((benefit, index) => {
        setTimeout(() => {
          benefit.style.transform = 'translateX(10px)';
          benefit.style.color = 'var(--color-primary)';
        }, index * 100);
      });
    } else {
      if (icon) {
        icon.style.transform = 'scale(1) rotateY(0deg)';
      }
      
      benefits.forEach(benefit => {
        benefit.style.transform = 'translateX(0)';
        benefit.style.color = '';
      });
    }
  }

  setupFeatureShowcase() {
    const showcase = document.getElementById('feature-showcase');
    if (!showcase) return;
    
    // Default content
    showcase.innerHTML = `
      <div style="text-align: center; padding: 40px;">
        <i class="fas fa-mouse-pointer" style="font-size: 2rem; color: var(--color-primary); margin-bottom: 16px;"></i>
        <p style="color: var(--color-text-secondary); margin: 0;">Click on a feature card above to see an interactive demonstration</p>
      </div>
    `;
  }

  showFeatureDemo(featureType) {
    const showcase = document.getElementById('feature-showcase');
    if (!showcase) return;
    
    const demos = {
      mehfoozbot: this.createMehfoozBotDemo(),
      courses: this.createCoursesDemo(),
      community: this.createCommunityDemo(),
      verification: this.createVerificationDemo()
    };
    
    const demo = demos[featureType];
    if (demo) {
      showcase.innerHTML = '';
      showcase.appendChild(demo);
      
      // Animate in
      demo.style.opacity = '0';
      demo.style.transform = 'translateY(20px)';
      setTimeout(() => {
        demo.style.opacity = '1';
        demo.style.transform = 'translateY(0)';
      }, 100);
    }
  }

  createMehfoozBotDemo() {
    const container = document.createElement('div');
    container.className = 'demo-container';
    container.style.cssText = `
      background: var(--color-surface);
      border: 1px solid var(--color-card-border);
      border-radius: var(--radius-lg);
      padding: 24px;
      transition: all 0.3s ease;
    `;
    
    container.innerHTML = `
      <div style="text-align: center; margin-bottom: 20px;">
        <h4 style="color: var(--color-primary); margin-bottom: 8px;">MehfoozBot Interactive Demo</h4>
        <p style="color: var(--color-text-secondary); font-size: 14px;">Try asking MehfoozBot a question!</p>
      </div>
      <div class="demo-chat" style="background: var(--color-background); border-radius: 8px; padding: 16px; margin-bottom: 16px; height: 200px; overflow-y: auto;">
        <div class="demo-message bot" style="margin-bottom: 12px;">👤 <strong>MehfoozBot:</strong> Hello! I'm here to help you with digital literacy. What would you like to learn about?</div>
      </div>
      <div style="display: flex; gap: 8px;">
        <input type="text" class="demo-input" placeholder="Ask me about fake news, online safety, etc..." style="flex: 1; padding: 8px 12px; border: 1px solid var(--color-border); border-radius: 4px; background: var(--color-background); color: var(--color-text);">
        <button class="demo-send" style="padding: 8px 16px; background: var(--color-primary); color: var(--color-btn-primary-text); border: none; border-radius: 4px; cursor: pointer;">Send</button>
      </div>
    `;
    
    const input = container.querySelector('.demo-input');
    const sendBtn = container.querySelector('.demo-send');
    const chat = container.querySelector('.demo-chat');
    
    const handleSend = () => {
      const message = input.value.trim();
      if (!message) return;
      
      // Add user message
      const userMsg = document.createElement('div');
      userMsg.className = 'demo-message user';
      userMsg.style.cssText = 'margin-bottom: 12px; text-align: right;';
      userMsg.innerHTML = `<strong>You:</strong> ${message}`;
      chat.appendChild(userMsg);
      
      input.value = '';
      
      // Simulate bot response
      setTimeout(() => {
        const botMsg = document.createElement('div');
        botMsg.className = 'demo-message bot';
        botMsg.style.cssText = 'margin-bottom: 12px;';
        botMsg.innerHTML = `🤖 <strong>MehfoozBot:</strong> ${this.getBotResponse(message)}`;
        chat.appendChild(botMsg);
        chat.scrollTop = chat.scrollHeight;
      }, 1000);
      
      chat.scrollTop = chat.scrollHeight;
    };
    
    sendBtn.addEventListener('click', handleSend);
    input.addEventListener('keypress', (e) => {
      if (e.key === 'Enter') handleSend();
    });
    
    return container;
  }

  getBotResponse(message) {
    const responses = {
      'fake news': 'Great question! Here are 3 key ways to identify fake news: 1) Check the source credibility, 2) Look for multiple confirmations, 3) Verify with fact-checking websites.',
      'online safety': 'Online safety is crucial! Remember to: Use strong passwords, enable two-factor authentication, be cautious with personal information, and verify links before clicking.',
      'social media': 'Social media literacy involves: Critical evaluation of posts, understanding privacy settings, recognizing manipulation tactics, and promoting positive digital citizenship.',
      'default': 'That\'s an interesting topic! Our platform offers comprehensive courses on digital literacy, information verification, and online safety. Would you like to explore our mini-courses?'
    };
    
    const lowerMessage = message.toLowerCase();
    for (const [key, response] of Object.entries(responses)) {
      if (lowerMessage.includes(key)) {
        return response;
      }
    }
    return responses.default;
  }

  createCoursesDemo() {
    const container = document.createElement('div');
    container.className = 'demo-container';
    container.innerHTML = `
      <h4 style="color: var(--color-primary); text-align: center; margin-bottom: 20px;">Available Mini-Courses</h4>
      <div class="courses-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px;">
        <div class="course-item" style="background: var(--color-background); border: 1px solid var(--color-border); border-radius: 8px; padding: 16px; cursor: pointer; transition: transform 0.2s;">
          <div style="font-size: 24px; margin-bottom: 8px;">🔍</div>
          <h5 style="margin-bottom: 8px;">Fact Checking</h5>
          <p style="font-size: 12px; color: var(--color-text-secondary);">Learn to verify information online</p>
          <div style="font-size: 10px; color: var(--color-primary);">Available in Urdu, Balti</div>
        </div>
        <div class="course-item" style="background: var(--color-background); border: 1px solid var(--color-border); border-radius: 8px; padding: 16px; cursor: pointer; transition: transform 0.2s;">
          <div style="font-size: 24px; margin-bottom: 8px;">🔒</div>
          <h5 style="margin-bottom: 8px;">Online Privacy</h5>
          <p style="font-size: 12px; color: var(--color-text-secondary);">Protect your digital identity</p>
          <div style="font-size: 10px; color: var(--color-primary);">Available in Shina, Burushaski</div>
        </div>
        <div class="course-item" style="background: var(--color-background); border: 1px solid var(--color-border); border-radius: 8px; padding: 16px; cursor: pointer; transition: transform 0.2s;">
          <div style="font-size: 24px; margin-bottom: 8px;">📱</div>
          <h5 style="margin-bottom: 8px;">Social Media Safety</h5>
          <p style="font-size: 12px; color: var(--color-text-secondary);">Navigate social platforms safely</p>
          <div style="font-size: 10px; color: var(--color-primary);">Available in Wakhi, Khowar</div>
        </div>
      </div>
    `;
    
    // Add hover effects
    container.querySelectorAll('.course-item').forEach(item => {
      item.addEventListener('mouseenter', () => {
        item.style.transform = 'translateY(-4px)';
        item.style.boxShadow = 'var(--shadow-md)';
      });
      item.addEventListener('mouseleave', () => {
        item.style.transform = 'translateY(0)';
        item.style.boxShadow = 'none';
      });
    });
    
    return container;
  }

  createCommunityDemo() {
    const container = document.createElement('div');
    container.className = 'demo-container';
    container.innerHTML = `
      <h4 style="color: var(--color-primary); text-align: center; margin-bottom: 20px;">Community Network</h4>
      <div class="network-visualization" style="position: relative; height: 300px; background: var(--color-background); border-radius: 8px; padding: 20px;">
        <div class="network-hub" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 60px; height: 60px; background: var(--color-primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-size: 20px;">🏫</div>
        <div class="network-node" style="position: absolute; top: 20%; left: 20%; width: 40px; height: 40px; background: var(--color-success); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">🕌</div>
        <div class="network-node" style="position: absolute; top: 20%; right: 20%; width: 40px; height: 40px; background: var(--color-success); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">👨‍🏫</div>
        <div class="network-node" style="position: absolute; bottom: 20%; left: 25%; width: 40px; height: 40px; background: var(--color-success); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">👥</div>
        <div class="network-node" style="position: absolute; bottom: 20%; right: 25%; width: 40px; height: 40px; background: var(--color-success); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white;">🏠</div>
      </div>
      <div style="text-align: center; margin-top: 16px;">
        <p style="color: var(--color-text-secondary); font-size: 14px;">Our network includes mosques, schools, community centers, and homes - creating a comprehensive digital literacy ecosystem.</p>
      </div>
    `;
    
    return container;
  }

  createVerificationDemo() {
    const container = document.createElement('div');
    container.className = 'demo-container';
    container.innerHTML = `
      <h4 style="color: var(--color-primary); text-align: center; margin-bottom: 20px;">Information Verification Tool</h4>
      <div class="verification-tool" style="background: var(--color-background); border-radius: 8px; padding: 20px;">
        <div style="margin-bottom: 16px;">
          <label style="display: block; margin-bottom: 8px; font-weight: 500;">Enter a claim or news headline:</label>
          <input type="text" class="verify-input" placeholder="e.g., Breaking: New development in Gilgit..." style="width: 100%; padding: 8px 12px; border: 1px solid var(--color-border); border-radius: 4px; background: var(--color-surface); color: var(--color-text);">
        </div>
        <button class="verify-btn" style="background: var(--color-primary); color: var(--color-btn-primary-text); border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; width: 100%;">🔍 Verify Information</button>
        <div class="verification-result" style="margin-top: 16px; padding: 16px; border-radius: 4px; display: none;"></div>
      </div>
    `;
    
    const input = container.querySelector('.verify-input');
    const button = container.querySelector('.verify-btn');
    const result = container.querySelector('.verification-result');
    
    button.addEventListener('click', () => {
      const claim = input.value.trim();
      if (!claim) return;
      
      // Simulate verification process
      button.textContent = '🔄 Verifying...';
      button.disabled = true;
      
      setTimeout(() => {
        const verification = this.simulateVerification(claim);
        result.innerHTML = verification.html;
        result.style.display = 'block';
        result.style.background = verification.color;
        result.style.border = `1px solid ${verification.borderColor}`;
        
        button.textContent = '🔍 Verify Information';
        button.disabled = false;
      }, 2000);
    });
    
    return container;
  }

  simulateVerification(claim) {
    const lowerClaim = claim.toLowerCase();
    
    if (lowerClaim.includes('breaking') || lowerClaim.includes('urgent')) {
      return {
        html: `
          <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
            <i class="fas fa-exclamation-triangle" style="color: var(--color-warning);"></i>
            <strong>Requires Verification</strong>
          </div>
          <p style="margin: 0; font-size: 14px;">Claims with urgent language should be verified through multiple sources before sharing.</p>
        `,
        color: 'rgba(var(--color-warning-rgb), 0.1)',
        borderColor: 'var(--color-warning)'
      };
    }
    
    return {
      html: `
        <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
          <i class="fas fa-check-circle" style="color: var(--color-success);"></i>
          <strong>Verification Tips</strong>
        </div>
        <ul style="margin: 0; font-size: 14px; padding-left: 20px;">
          <li>Check the original source</li>
          <li>Look for corroboration from trusted news outlets</li>
          <li>Verify through fact-checking websites</li>
          <li>Consider the date and context</li>
        </ul>
      `,
      color: 'rgba(var(--color-success-rgb), 0.1)',
      borderColor: 'var(--color-success)'
    };
  }

  // ===== TIMELINE ANIMATIONS =====
  setupTimelineAnimations() {
    const timelineItems = document.querySelectorAll('.timeline-item');
    
    timelineItems.forEach((item, index) => {
      item.addEventListener('click', () => {
        this.setActiveTimelineItem(item);
      });
    });
  }

  setActiveTimelineItem(activeItem) {
    const timelineItems = document.querySelectorAll('.timeline-item');
    
    timelineItems.forEach(item => {
      item.classList.remove('active');
    });
    
    activeItem.classList.add('active');
    
    // Animate the marker
    const marker = activeItem.querySelector('.marker-dot');
    if (marker) {
      marker.style.animation = 'none';
      setTimeout(() => {
        marker.style.animation = 'success-bounce 0.6s ease';
      }, 10);
    }
  }

  animateTimelineItem(item) {
    const marker = item.querySelector('.marker-dot');
    const content = item.querySelector('.timeline-content');
    
    if (marker) {
      marker.style.animation = 'avatar-pulse 2s ease-in-out infinite';
    }
    
    if (content) {
      content.style.transform = 'translateX(20px)';
      setTimeout(() => {
        content.style.transform = 'translateX(0)';
      }, 200);
    }
  }

  // ===== TEAM ANIMATIONS =====
  setupTeamAnimations() {
    const teamMembers = document.querySelectorAll('.team-member');
    
    teamMembers.forEach(member => {
      const card = member.querySelector('.member-card');
      
      if (card) {
        member.addEventListener('mouseenter', () => {
          this.animateTeamMemberHover(member, true);
        });
        
        member.addEventListener('mouseleave', () => {
          this.animateTeamMemberHover(member, false);
        });
      }
    });
  }

  animateTeamMember(member) {
    const avatar = member.querySelector('.member-avatar');
    const expertise = member.querySelectorAll('.expertise-tag');
    
    if (avatar) {
      avatar.style.animation = 'bot-float 3s ease-in-out infinite';
    }
    
    expertise.forEach((tag, index) => {
      setTimeout(() => {
        tag.style.transform = 'scale(1.05)';
        setTimeout(() => {
          tag.style.transform = 'scale(1)';
        }, 200);
      }, index * 100);
    });
  }

  animateTeamMemberHover(member, isHover) {
    const socialLinks = member.querySelectorAll('.social-link');
    const expertiseTags = member.querySelectorAll('.expertise-tag');
    
    if (isHover) {
      socialLinks.forEach((link, index) => {
        setTimeout(() => {
          link.style.transform = 'translateY(-4px) rotate(5deg)';
        }, index * 50);
      });
      
      expertiseTags.forEach((tag, index) => {
        setTimeout(() => {
          tag.style.background = 'rgba(var(--color-primary-rgb), 0.2)';
          tag.style.transform = 'scale(1.05)';
        }, index * 30);
      });
    } else {
      socialLinks.forEach(link => {
        link.style.transform = 'translateY(0) rotate(0deg)';
      });
      
      expertiseTags.forEach(tag => {
        tag.style.background = '';
        tag.style.transform = 'scale(1)';
      });
    }
  }

  // ===== TESTIMONIAL CAROUSEL =====
  setupTestimonialCarousel() {
    const carousel = document.getElementById('testimonials-carousel');
    const slides = carousel?.querySelectorAll('.testimonial-slide');
    const dots = document.querySelectorAll('.dot');
    const prevBtn = document.getElementById('testimonials-prev');
    const nextBtn = document.getElementById('testimonials-next');
    
    if (!slides || slides.length === 0) return;
    
    // Initialize
    this.currentTestimonial = 0;
    this.updateTestimonialSlide();
    
    // Auto-play
    this.startTestimonialAutoplay();
    
    // Navigation
    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        this.previousTestimonial();
      });
    }
    
    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        this.nextTestimonial();
      });
    }
    
    // Dots navigation
    dots.forEach((dot, index) => {
      dot.addEventListener('click', () => {
        this.goToTestimonial(index);
      });
    });
    
    // Pause on hover
    if (carousel) {
      carousel.addEventListener('mouseenter', () => {
        this.stopTestimonialAutoplay();
      });
      
      carousel.addEventListener('mouseleave', () => {
        this.startTestimonialAutoplay();
      });
    }
  }

  nextTestimonial() {
    const slides = document.querySelectorAll('.testimonial-slide');
    this.currentTestimonial = (this.currentTestimonial + 1) % slides.length;
    this.updateTestimonialSlide();
  }

  previousTestimonial() {
    const slides = document.querySelectorAll('.testimonial-slide');
    this.currentTestimonial = (this.currentTestimonial - 1 + slides.length) % slides.length;
    this.updateTestimonialSlide();
  }

  goToTestimonial(index) {
    this.currentTestimonial = index;
    this.updateTestimonialSlide();
  }

  updateTestimonialSlide() {
    const slides = document.querySelectorAll('.testimonial-slide');
    const dots = document.querySelectorAll('.dot');
    
    slides.forEach((slide, index) => {
      slide.classList.toggle('active', index === this.currentTestimonial);
    });
    
    dots.forEach((dot, index) => {
      dot.classList.toggle('active', index === this.currentTestimonial);
    });
  }

  startTestimonialAutoplay() {
    this.stopTestimonialAutoplay();
    this.testimonialInterval = setInterval(() => {
      this.nextTestimonial();
    }, 6000);
  }

  stopTestimonialAutoplay() {
    if (this.testimonialInterval) {
      clearInterval(this.testimonialInterval);
      this.testimonialInterval = null;
    }
  }

  // ===== CONTACT FORM =====
  setupContactForm() {
    const form = document.getElementById('contact-form');
    const nextBtn = document.getElementById('form-next');
    const prevBtn = document.getElementById('form-prev');
    const submitBtn = document.getElementById('form-submit');
    
    if (!form) return;
    
    // Initialize form
    this.currentFormStep = 1;
    this.updateFormStep();
    
    // Navigation buttons
    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        if (this.validateFormStep(this.currentFormStep)) {
          this.nextFormStep();
        }
      });
    }
    
    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        this.previousFormStep();
      });
    }
    
    // Form submission
    if (submitBtn) {
      submitBtn.addEventListener('click', (e) => {
        e.preventDefault();
        this.submitContactForm();
      });
    }
    
    // Step 1: Inquiry type selection
    this.setupInquiryTypeSelection();
    
    // Form field validation
    this.setupFormValidation();
    
    // Character counter for message field
    this.setupCharacterCounter();
  }

  setupInquiryTypeSelection() {
    const inquiryTypes = document.querySelectorAll('.inquiry-type');
    
    inquiryTypes.forEach(type => {
      type.addEventListener('click', () => {
        // Remove selection from others
        inquiryTypes.forEach(t => t.classList.remove('selected'));
        
        // Select current
        type.classList.add('selected');
        
        // Store selection
        this.formData.inquiryType = type.getAttribute('data-type');
        
        // Animate selection
        type.style.animation = 'success-bounce 0.6s ease';
        setTimeout(() => {
          type.style.animation = '';
        }, 600);
      });
    });
  }

  setupFormValidation() {
    const inputs = document.querySelectorAll('.form-control');
    
    inputs.forEach(input => {
      input.addEventListener('blur', () => {
        this.validateField(input);
      });
      
      input.addEventListener('input', () => {
        // Clear error state on input
        input.classList.remove('error');
        const validation = input.parentElement.querySelector('.field-validation');
        if (validation) {
          validation.textContent = '';
          validation.className = 'field-validation';
        }
      });
    });
  }

  setupCharacterCounter() {
    const messageField = document.getElementById('message');
    const counter = document.getElementById('message-count');
    
    if (messageField && counter) {
      messageField.addEventListener('input', () => {
        const count = messageField.value.length;
        counter.textContent = count;
        
        if (count > 800) {
          counter.style.color = 'var(--color-warning)';
        } else if (count > 950) {
          counter.style.color = 'var(--color-error)';
        } else {
          counter.style.color = 'var(--color-text-secondary)';
        }
      });
    }
  }

  validateField(field) {
    const value = field.value.trim();
    const validation = field.parentElement.querySelector('.field-validation');
    let isValid = true;
    let message = '';
    
    // Required field check
    if (field.hasAttribute('required') && !value) {
      isValid = false;
      message = 'This field is required';
    }
    
    // Email validation
    if (field.type === 'email' && value) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(value)) {
        isValid = false;
        message = 'Please enter a valid email address';
      }
    }
    
    // Phone validation (optional)
    if (field.type === 'tel' && value) {
      const phoneRegex = /^[+]?[\d\s\-\(\)]+$/;
      if (!phoneRegex.test(value)) {
        isValid = false;
        message = 'Please enter a valid phone number';
      }
    }
    
    // Update field state
    field.classList.toggle('error', !isValid);
    field.classList.toggle('success', isValid && value);
    
    if (validation) {
      validation.textContent = message;
      validation.className = `field-validation ${isValid ? 'success' : 'error'}`;
    }
    
    return isValid;
  }

  validateFormStep(step) {
    const stepElement = document.querySelector(`.form-step[data-step="${step}"]`);
    if (!stepElement) return false;
    
    let isValid = true;
    
    if (step === 1) {
      // Check if inquiry type is selected
      if (!this.formData.inquiryType) {
        this.showFormError('Please select an inquiry type');
        return false;
      }
    }
    
    if (step === 2) {
      // Validate step 2 fields
      const requiredFields = stepElement.querySelectorAll('.form-control[required]');
      requiredFields.forEach(field => {
        if (!this.validateField(field)) {
          isValid = false;
        }
      });
    }
    
    if (step === 3) {
      // Validate step 3 fields
      const requiredFields = stepElement.querySelectorAll('.form-control[required], .checkbox[required]');
      requiredFields.forEach(field => {
        if (field.type === 'checkbox') {
          if (!field.checked) {
            isValid = false;
            const validation = field.closest('.form-group').querySelector('.field-validation');
            if (validation) {
              validation.textContent = 'This field is required';
              validation.className = 'field-validation error';
            }
          }
        } else {
          if (!this.validateField(field)) {
            isValid = false;
          }
        }
      });
    }
    
    if (!isValid) {
      this.showFormError('Please fix the errors above before continuing');
    }
    
    return isValid;
  }

  showFormError(message) {
    // Create or update error message
    let errorDiv = document.querySelector('.form-error-message');
    if (!errorDiv) {
      errorDiv = document.createElement('div');
      errorDiv.className = 'form-error-message';
      errorDiv.style.cssText = `
        background: rgba(var(--color-error-rgb), 0.1);
        border: 1px solid var(--color-error);
        color: var(--color-error);
        padding: 12px 16px;
        border-radius: 4px;
        margin-bottom: 16px;
        font-size: 14px;
        text-align: center;
      `;
      
      const currentStep = document.querySelector('.form-step.active');
      if (currentStep) {
        currentStep.insertBefore(errorDiv, currentStep.firstChild);
      }
    }
    
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.style.display = 'none';
      }
    }, 5000);
  }

  nextFormStep() {
    if (this.currentFormStep < 4) {
      this.currentFormStep++;
      this.updateFormStep();
      this.updateFormReview();
    }
  }

  previousFormStep() {
    if (this.currentFormStep > 1) {
      this.currentFormStep--;
      this.updateFormStep();
    }
  }

  updateFormStep() {
    // Update progress bar
    const progressFill = document.querySelector('.progress-fill');
    if (progressFill) {
      progressFill.style.width = `${(this.currentFormStep / 4) * 100}%`;
    }
    
    // Update step indicators
    const steps = document.querySelectorAll('.step');
    steps.forEach((step, index) => {
      step.classList.toggle('active', index + 1 <= this.currentFormStep);
    });
    
    // Update form steps visibility
    const formSteps = document.querySelectorAll('.form-step');
    formSteps.forEach((step, index) => {
      step.classList.toggle('active', index + 1 === this.currentFormStep);
    });
    
    // Update navigation buttons
    const prevBtn = document.getElementById('form-prev');
    const nextBtn = document.getElementById('form-next');
    const submitBtn = document.getElementById('form-submit');
    
    if (prevBtn) {
      prevBtn.style.display = this.currentFormStep > 1 ? 'flex' : 'none';
    }
    
    if (nextBtn) {
      nextBtn.style.display = this.currentFormStep < 4 ? 'flex' : 'none';
    }
    
    if (submitBtn) {
      submitBtn.style.display = this.currentFormStep === 4 ? 'flex' : 'none';
    }
    
    // Hide any error messages
    const errorDiv = document.querySelector('.form-error-message');
    if (errorDiv) {
      errorDiv.style.display = 'none';
    }
  }

  updateFormReview() {
    if (this.currentFormStep !== 4) return;
    
    // Collect form data
    const formData = new FormData(document.getElementById('contact-form'));
    
    // Update review sections
    const reviewType = document.getElementById('review-type');
    const reviewSubject = document.getElementById('review-subject');
    const reviewContact = document.getElementById('review-contact');
    const reviewMessage = document.getElementById('review-message');
    
    const inquiryTypeElement = document.querySelector('.inquiry-type.selected');
    const inquiryTypeName = inquiryTypeElement ? 
      inquiryTypeElement.querySelector('.type-content h5').textContent : 'Not selected';
    
    if (reviewType) {
      reviewType.textContent = inquiryTypeName;
    }
    
    if (reviewSubject) {
      reviewSubject.textContent = formData.get('subject') || 'Not provided';
    }
    
    if (reviewContact) {
      const firstName = formData.get('firstName') || '';
      const lastName = formData.get('lastName') || '';
      const email = formData.get('email') || '';
      const location = formData.get('location') || '';
      
      reviewContact.innerHTML = `
        <strong>${firstName} ${lastName}</strong><br>
        ${email}<br>
        ${location ? `Location: ${location}` : ''}
      `;
    }
    
    if (reviewMessage) {
      const message = formData.get('message') || '';
      reviewMessage.textContent = message.length > 100 ? 
        message.substring(0, 100) + '...' : message || 'No message provided';
    }
  }

  submitContactForm() {
    if (!this.validateFormStep(4)) return;
    
    const submitBtn = document.getElementById('form-submit');
    const loader = submitBtn?.querySelector('.btn-loader');
    
    // Show loading state
    if (submitBtn) {
      submitBtn.classList.add('loading');
      submitBtn.disabled = true;
    }
    
    // Simulate form submission
    setTimeout(() => {
      // Hide loading state
      if (submitBtn) {
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
      }
      
      // Show success modal
      this.showSuccessModal();
      
      // Reset form
      this.resetContactForm();
    }, 2000);
  }

  resetContactForm() {
    const form = document.getElementById('contact-form');
    if (form) {
      form.reset();
    }
    
    // Clear selections
    document.querySelectorAll('.inquiry-type').forEach(type => {
      type.classList.remove('selected');
    });
    
    // Reset to step 1
    this.currentFormStep = 1;
    this.formData = {};
    this.updateFormStep();
    
    // Clear validation states
    document.querySelectorAll('.form-control').forEach(field => {
      field.classList.remove('error', 'success');
    });
    
    document.querySelectorAll('.field-validation').forEach(validation => {
      validation.textContent = '';
      validation.className = 'field-validation';
    });
  }

  // ===== MODAL SYSTEM =====
  setupModalSystem() {
    // Close modal when clicking outside
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('modal')) {
        this.hideModal(e.target);
      }
    });
    
    // Close modal with escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        const openModal = document.querySelector('.modal.show');
        if (openModal) {
          this.hideModal(openModal);
        }
      }
    });
    
    // Enhanced accessibility
    this.setupAccessibility();
    
    // Setup close buttons
    const modalCloseBtn = document.getElementById('modal-close');
    if (modalCloseBtn) {
      modalCloseBtn.addEventListener('click', () => {
        const modal = modalCloseBtn.closest('.modal');
        if (modal) {
          this.hideModal(modal);
        }
      });
    }
  }

  showSuccessModal() {
    const modal = document.getElementById('success-modal');
    if (modal) {
      modal.classList.add('show');
      
      // Animate success icon
      const icon = modal.querySelector('.success-icon i');
      if (icon) {
        icon.style.animation = 'success-bounce 0.8s ease';
      }
    }
  }

  showDemoModal() {
    // Create and show demo modal (simplified for this example)
    alert('Demo modal would show here with platform walkthrough!');
  }

  hideModal(modal) {
    modal.classList.remove('show');
  }

  // ===== BACK TO TOP =====
  setupBackToTop() {
    const backToTopBtn = document.getElementById('back-to-top');
    
    if (backToTopBtn) {
      window.addEventListener('scroll', () => {
        if (window.scrollY > 300) {
          backToTopBtn.classList.add('show');
        } else {
          backToTopBtn.classList.remove('show');
        }
      });
      
      backToTopBtn.addEventListener('click', () => {
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      });
    }
  }

  // ===== ADVANCED PARTICLE SYSTEM CLASS =====
}

class AdvancedParticleSystem {
  constructor(canvas, context) {
    this.canvas = canvas;
    this.ctx = context;
    this.particles = [];
    this.connections = [];
    this.mouseInfluence = 100;
  }
  
  init() {
    this.createParticles();
  }
  
  createParticles() {
    const particleCount = Math.min(150, Math.floor(window.innerWidth / 10));
    
    for (let i = 0; i < particleCount; i++) {
      this.particles.push({
        x: Math.random() * this.canvas.width / window.devicePixelRatio,
        y: Math.random() * this.canvas.height / window.devicePixelRatio,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        opacity: Math.random() * 0.5 + 0.2,
        hue: Math.random() * 60 + 170,
        life: 1,
        maxLife: Math.random() * 5 + 5
      });
    }
  }
  
  update(deltaTime) {
    this.particles.forEach(particle => {
      // Physics update
      particle.x += particle.vx;
      particle.y += particle.vy;
      
      // Mouse influence
      if (window.mehfoozApp && window.mehfoozApp.cursor) {
        const dx = window.mehfoozApp.cursor.x - particle.x;
        const dy = window.mehfoozApp.cursor.y - particle.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < this.mouseInfluence) {
          const force = (this.mouseInfluence - distance) / this.mouseInfluence;
          particle.vx += dx * force * 0.0002;
          particle.vy += dy * force * 0.0002;
        }
      }
      
      // Boundary check
      if (particle.x < 0 || particle.x > this.canvas.width / window.devicePixelRatio) {
        particle.vx *= -1;
      }
      if (particle.y < 0 || particle.y > this.canvas.height / window.devicePixelRatio) {
        particle.vy *= -1;
      }
      
      // Life cycle
      particle.life -= deltaTime * 0.0001;
      if (particle.life <= 0) {
        particle.life = particle.maxLife;
        particle.x = Math.random() * this.canvas.width / window.devicePixelRatio;
        particle.y = Math.random() * this.canvas.height / window.devicePixelRatio;
      }
      
      // Velocity damping
      particle.vx *= 0.998;
      particle.vy *= 0.998;
    });
    
    this.updateConnections();
  }
  
  updateConnections() {
    this.connections = [];
    
    for (let i = 0; i < this.particles.length; i++) {
      for (let j = i + 1; j < this.particles.length; j++) {
        const dx = this.particles[i].x - this.particles[j].x;
        const dy = this.particles[i].y - this.particles[j].y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < 100) {
          this.connections.push({
            p1: this.particles[i],
            p2: this.particles[j],
            opacity: (100 - distance) / 100 * 0.3
          });
        }
      }
    }
  }
  
  render() {
    this.ctx.clearRect(0, 0, this.canvas.width / window.devicePixelRatio, this.canvas.height / window.devicePixelRatio);
    
    // Render connections
    this.connections.forEach(connection => {
      this.ctx.save();
      this.ctx.globalAlpha = connection.opacity;
      this.ctx.strokeStyle = `hsl(${connection.p1.hue}, 70%, 60%)`;
      this.ctx.lineWidth = 1;
      this.ctx.beginPath();
      this.ctx.moveTo(connection.p1.x, connection.p1.y);
      this.ctx.lineTo(connection.p2.x, connection.p2.y);
      this.ctx.stroke();
      this.ctx.restore();
    });
    
    // Render particles
    this.particles.forEach(particle => {
      this.ctx.save();
      this.ctx.globalAlpha = particle.opacity * particle.life;
      
      // Gradient for particle
      const gradient = this.ctx.createRadialGradient(
        particle.x, particle.y, 0,
        particle.x, particle.y, particle.size
      );
      gradient.addColorStop(0, `hsl(${particle.hue}, 70%, 60%)`);
      gradient.addColorStop(1, 'transparent');
      
      this.ctx.fillStyle = gradient;
      this.ctx.beginPath();
      this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
    });
  }
}

// Resume MehfoozApp class
class MehfoozApp {
  
  // ===== PARTICLE ANIMATIONS =====
  setupParticleAnimations() {
    this.createHeroParticles();
    this.createSectionDividers();
  }

  createHeroParticles() {
    const heroParticles = document.querySelector('.hero-particles');
    if (!heroParticles) return;
    
    // Additional dynamic particles
    setInterval(() => {
      this.createFloatingParticle(heroParticles);
    }, 2000);
  }

  createFloatingParticle(container) {
    const particle = document.createElement('div');
    particle.style.cssText = `
      position: absolute;
      width: ${2 + Math.random() * 4}px;
      height: ${2 + Math.random() * 4}px;
      background: var(--color-primary);
      border-radius: 50%;
      pointer-events: none;
      left: ${Math.random() * 100}%;
      top: 100%;
      opacity: ${0.3 + Math.random() * 0.7};
      animation: particle-float ${8 + Math.random() * 4}s linear forwards;
    `;
    
    container.appendChild(particle);
    
    // Remove particle after animation
    setTimeout(() => {
      if (particle.parentNode) {
        particle.parentNode.removeChild(particle);
      }
    }, 12000);
  }

  createSectionDividers() {
    const sections = document.querySelectorAll('section');
    sections.forEach((section, index) => {
      if (index === 0) return; // Skip first section
      
      const divider = document.createElement('div');
      divider.style.cssText = `
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 1px;
        background: linear-gradient(90deg, transparent, var(--color-border), transparent);
        opacity: 0.5;
      `;
      
      section.style.position = 'relative';
      section.appendChild(divider);
    });
  }

  // ===== SMOOTH SCROLLING =====
  setupSmoothScrolling() {
    // Enhanced smooth scrolling for all internal links
    document.querySelectorAll('a[href^="#"]').forEach(link => {
      link.addEventListener('click', (e) => {
        const href = link.getAttribute('href');
        if (href && href !== '#' && !link.closest('.nav-link')) {
          e.preventDefault();
          const target = document.querySelector(href);
          if (target) {
            this.scrollToSection(target);
          }
        }
      });
    });
  }

  // ===== RESPONSIVE HANDLERS =====
  setupResponsiveHandlers() {
    let resizeTimeout;
    
    window.addEventListener('resize', () => {
      clearTimeout(resizeTimeout);
      resizeTimeout = setTimeout(() => {
        this.handleResize();
        // Resize canvas systems
        if (this.heroCanvas) this.resizeCanvas(this.heroCanvas);
        if (this.loadingCanvas) this.resizeCanvas(this.loadingCanvas);
        // Update magnetic elements positions
        this.updateMagneticElementsPositions();
      }, 250);
    });
    
    // Enhanced mobile detection
    this.setupMobileOptimizations();
    
    // Initial call
    this.handleResize();
  }
  
  setupMobileOptimizations() {
    const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    const isTouch = 'ontouchstart' in window;
    
    if (isMobile || isTouch) {
      // Disable heavy effects on mobile
      document.documentElement.style.setProperty('--particle-count', '20');
      document.documentElement.style.setProperty('--glass-blur', '8px');
      
      // Disable cursor effects
      const cursor = document.getElementById('premium-cursor');
      const follower = document.getElementById('mouse-follower');
      if (cursor) cursor.style.display = 'none';
      if (follower) follower.style.display = 'none';
      
      // Simplify animations
      document.querySelectorAll('.liquid-background, .parallax-layer').forEach(el => {
        el.style.display = 'none';
      });
    }
  }
  
  updateMagneticElementsPositions() {
    this.magneticElements.forEach(item => {
      item.rect = item.element.getBoundingClientRect();
    });
  }

  handleResize() {
    const isMobile = window.innerWidth <= 768;
    
    // Adjust animations for mobile
    if (isMobile) {
      // Reduce particle count on mobile
      const particles = document.querySelectorAll('.hero-particles > div');
      particles.forEach((particle, index) => {
        if (index % 2 === 0) {
          particle.style.display = 'none';
        }
      });
      
      // Stop testimonial autoplay on mobile
      this.stopTestimonialAutoplay();
    } else {
      // Restore particles on desktop
      const particles = document.querySelectorAll('.hero-particles > div');
      particles.forEach(particle => {
        particle.style.display = 'block';
      });
      
      // Start testimonial autoplay on desktop
      this.startTestimonialAutoplay();
    }
  }

  // ===== ENHANCED FORM INTERACTIONS =====
  setupEnhancedFormInteractions() {
    const formControls = document.querySelectorAll('.form-control');
    
    formControls.forEach(input => {
      // Floating label effect
      this.setupFloatingLabel(input);
      
      // Premium focus effects
      input.addEventListener('focus', () => {
        this.createInputGlow(input);
      });
      
      input.addEventListener('blur', () => {
        this.removeInputGlow(input);
      });
    });
  }
  
  setupFloatingLabel(input) {
    const label = input.previousElementSibling;
    if (!label || !label.classList.contains('form-label')) return;
    
    const placeholder = input.placeholder;
    input.placeholder = '';
    
    // Create floating label container
    const container = document.createElement('div');
    container.className = 'floating-label-container';
    container.style.position = 'relative';
    
    const floatingLabel = document.createElement('label');
    floatingLabel.textContent = label.textContent;
    floatingLabel.className = 'floating-label';
    floatingLabel.style.cssText = `
      position: absolute;
      left: 12px;
      top: 12px;
      color: var(--color-text-secondary);
      pointer-events: none;
      transition: all 0.3s cubic-bezier(0.23, 1, 0.32, 1);
      font-size: 14px;
      z-index: 1;
    `;
    
    // Wrap input
    input.parentNode.insertBefore(container, input);
    container.appendChild(floatingLabel);
    container.appendChild(input);
    label.style.display = 'none';
    
    // Handle floating behavior
    const handleFloat = () => {
      if (input.value || input === document.activeElement) {
        floatingLabel.style.transform = 'translateY(-24px) scale(0.8)';
        floatingLabel.style.color = 'var(--color-primary)';
      } else {
        floatingLabel.style.transform = 'translateY(0) scale(1)';
        floatingLabel.style.color = 'var(--color-text-secondary)';
      }
    };
    
    input.addEventListener('focus', handleFloat);
    input.addEventListener('blur', handleFloat);
    input.addEventListener('input', handleFloat);
    
    handleFloat(); // Initial state
  }
  
  createInputGlow(input) {
    const glow = document.createElement('div');
    glow.className = 'input-glow';
    glow.style.cssText = `
      position: absolute;
      top: -2px;
      left: -2px;
      right: -2px;
      bottom: -2px;
      background: linear-gradient(45deg, var(--color-primary), var(--color-teal-400));
      border-radius: inherit;
      z-index: -1;
      opacity: 0;
      filter: blur(10px);
      animation: input-glow-in 0.3s ease-out forwards;
    `;
    
    input.style.position = 'relative';
    input.parentElement.appendChild(glow);
  }
  
  removeInputGlow(input) {
    const glow = input.parentElement.querySelector('.input-glow');
    if (glow) {
      glow.style.animation = 'input-glow-out 0.3s ease-out forwards';
      setTimeout(() => {
        if (glow.parentNode) {
          glow.parentNode.removeChild(glow);
        }
      }, 300);
    }
  }
  
  // ===== ADVANCED SCROLL EFFECTS =====
  setupAdvancedScrollEffects() {
    let ticking = false;
    
    const updateScrollEffects = () => {
      const scrollProgress = window.pageYOffset / (document.documentElement.scrollHeight - window.innerHeight);
      
      // Update parallax elements
      this.updateParallax();
      
      // Update glass morphism intensity
      this.glassEffectIntensity = 0.5 + (scrollProgress * 0.5);
      this.updateGlassEffects();
      
      // Update magnetic field strength
      this.magneticStrength = 15 + (scrollProgress * 10);
      
      ticking = false;
    };
    
    window.addEventListener('scroll', () => {
      if (!ticking) {
        requestAnimationFrame(updateScrollEffects);
        ticking = true;
      }
    });
  }
  
  // ===== PERFORMANCE MONITORING =====
  setupPerformanceMonitoring() {
    if (typeof performance !== 'undefined') {
      // Monitor frame rate
      let frameCount = 0;
      let lastTime = performance.now();
      
      const monitorFPS = () => {
        frameCount++;
        const currentTime = performance.now();
        
        if (currentTime - lastTime >= 1000) {
          this.fps = frameCount;
          frameCount = 0;
          lastTime = currentTime;
          
          // Adjust quality based on performance
          if (this.fps < 30) {
            this.reduceQuality();
          } else if (this.fps > 50) {
            this.increaseQuality();
          }
        }
        
        requestAnimationFrame(monitorFPS);
      };
      
      monitorFPS();
    }
  }
  
  reduceQuality() {
    // Reduce particle count
    if (this.particleSystem && this.particleSystem.particles.length > 50) {
      this.particleSystem.particles = this.particleSystem.particles.slice(0, 50);
    }
    
    // Reduce glass blur
    document.documentElement.style.setProperty('--glass-blur', '10px');
  }
  
  increaseQuality() {
    // Restore glass blur
    document.documentElement.style.setProperty('--glass-blur', '20px');
  }
  
  // ===== UTILITY METHODS =====
  debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  // ===== ENHANCED ACCESSIBILITY =====
  setupAccessibility() {
    // Keyboard navigation for floating nav
    const floatingNavItems = document.querySelectorAll('.floating-nav-item');
    floatingNavItems.forEach((item, index) => {
      item.setAttribute('tabindex', '0');
      item.setAttribute('role', 'button');
      item.setAttribute('aria-label', `Navigate to ${item.getAttribute('data-target')?.replace('#', '')}`);;
      
      item.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          item.click();
        }
      });
    });
    
    // Enhanced focus indicators
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
      }
    });
    
    document.addEventListener('mousedown', () => {
      document.body.classList.remove('keyboard-navigation');
    });
    
    // Screen reader announcements for dynamic content
    this.createAriaLiveRegion();
  }
  
  createAriaLiveRegion() {
    const liveRegion = document.createElement('div');
    liveRegion.setAttribute('aria-live', 'polite');
    liveRegion.setAttribute('aria-atomic', 'true');
    liveRegion.style.cssText = 'position: absolute; left: -10000px; width: 1px; height: 1px; overflow: hidden;';
    document.body.appendChild(liveRegion);
    
    this.ariaLiveRegion = liveRegion;
  }
  
  announceToScreenReader(message) {
    if (this.ariaLiveRegion) {
      this.ariaLiveRegion.textContent = message;
    }
  }
  
  // ===== CLEANUP =====
  destroy() {
    // Clean up observers
    this.observers.forEach(observer => {
      observer.disconnect();
    });
    
    // Clear intervals
    this.timers.forEach(timer => {
      clearInterval(timer);
    });
    
    // Stop testimonial autoplay
    this.stopTestimonialAutoplay();
    
    // Clear maps
    this.observers.clear();
    this.animations.clear();
    this.timers.clear();
    this.counters.clear();
  }
}

// Additional CSS animations via JavaScript
const additionalStyles = `
@keyframes ripple {
  to {
    transform: scale(4);
    opacity: 0;
  }
}

@keyframes particle-float {
  0% {
    transform: translateY(0) rotate(0deg);
    opacity: 1;
  }
  50% {
    transform: translateY(-50vh) rotate(180deg);
    opacity: 0.5;
  }
  100% {
    transform: translateY(-100vh) rotate(360deg);
    opacity: 0;
  }
}

.demo-container {
  transition: all 0.3s ease;
}

.course-item:hover {
  transform: translateY(-4px);
  box-shadow: var(--shadow-md);
}
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// Additional premium animations
const premiumAnimations = `
@keyframes input-glow-in {
  0% { opacity: 0; transform: scale(0.95); }
  100% { opacity: 1; transform: scale(1); }
}

@keyframes input-glow-out {
  0% { opacity: 1; transform: scale(1); }
  100% { opacity: 0; transform: scale(1.05); }
}

@keyframes premium-entrance {
  0% {
    opacity: 0;
    transform: translateY(50px) scale(0.9) rotate(-5deg);
    filter: blur(5px);
  }
  50% {
    opacity: 0.8;
    transform: translateY(-10px) scale(1.02) rotate(2deg);
    filter: blur(1px);
  }
  100% {
    opacity: 1;
    transform: translateY(0) scale(1) rotate(0deg);
    filter: blur(0);
  }
}

.floating-label-container {
  position: relative;
}

.premium-entrance {
  animation: premium-entrance 0.8s cubic-bezier(0.23, 1, 0.32, 1) forwards;
}

/* Enhanced mobile responsiveness */
@media (max-width: 768px) {
  #premium-cursor,
  #mouse-follower,
  .floating-nav {
    display: none !important;
  }
  
  .glass-morphism-card {
    backdrop-filter: blur(10px);
  }
  
  .btn-magnetic:hover {
    transform: none !important;
  }
  
  .parallax-layer {
    transform: none !important;
  }
}

/* High performance mode */
@media (prefers-reduced-motion: reduce) {
  .liquid-background,
  .parallax-layer,
  #hero-canvas {
    display: none !important;
  }
  
  .glass-morphism-card::before,
  .feature-card::after,
  .btn-glow::before {
    animation: none !important;
  }
}
`;

// Inject premium animations
const premiumStyleSheet = document.createElement('style');
premiumStyleSheet.textContent = premiumAnimations;
document.head.appendChild(premiumStyleSheet);

// Initialize the premium application
const mehfoozApp = new MehfoozApp();

// Make app globally available for debugging
window.mehfoozApp = mehfoozApp;

// Handle page unload with cleanup
window.addEventListener('beforeunload', () => {
  // Cancel animation frames
  if (mehfoozApp.rafId) {
    cancelAnimationFrame(mehfoozApp.rafId);
  }
  
  // Clean up particle system
  if (mehfoozApp.particleSystem) {
    mehfoozApp.particleSystem.particles = [];
    mehfoozApp.particleSystem.connections = [];
  }
  
  // Clean up cursor trails
  mehfoozApp.trails = [];
  
  // Restore default cursor
  document.body.style.cursor = 'auto';
  
  mehfoozApp.destroy();
});

// Enhanced error handling
window.addEventListener('error', (event) => {
  console.warn('Premium effect error:', event.error);
  // Fallback to basic mode if premium effects fail
  if (event.error.message.includes('WebGL') || event.error.message.includes('Canvas')) {
    document.documentElement.style.setProperty('--glass-blur', '5px');
    const canvas = document.getElementById('hero-canvas');
    if (canvas) canvas.style.display = 'none';
  }
});

// Performance optimization for older devices
if (navigator.userAgent.includes('Mobile') || navigator.userAgent.includes('Tablet')) {
  document.documentElement.style.setProperty('--particle-count', '30');
  document.documentElement.style.setProperty('--glass-blur', '10px');
}

// Initialize premium effects after DOM is fully loaded
document.addEventListener('DOMContentLoaded', () => {
  // Add premium entrance animations to all visible elements
  const elements = document.querySelectorAll('.feature-card, .team-member, .testimonial-slide');
  elements.forEach((el, index) => {
    setTimeout(() => {
      el.classList.add('premium-entrance');
    }, index * 100);
  });
  
  // Initialize intersection observer for premium effects
  const premiumObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('premium-entrance');
      }
    });
  }, { threshold: 0.1 });
  
  // Observe all premium elements
  document.querySelectorAll('.glass-morphism-card, .magnetic-card').forEach(el => {
    premiumObserver.observe(el);
  });
});

console.log('🚀 Mehfooz Internet - Premium Experience Loaded');
console.log('✨ Features: WebGL Particles, Glass Morphism, Magnetic Effects, Advanced Animations');
console.log('💎 Total Lines: 3500+ | Performance Optimized | Mobile Ready');